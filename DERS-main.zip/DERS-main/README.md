# Mini Platform Oyunu – HTML CSS JS

Bu proje, web tabanlı basit bir platform oyunu geliştirme ödevi için yapılmıştır.
Oyun HTML, CSS ve JavaScript ile sıfırdan yazılmıştır. Kütüphane kullanılmamıştır.

## Özellikler
- Nişan alma tarzı oyun
- Yerçekimi
- Sağ–sol hareket
- Tek dosya ile çalışır

## Kullanılan Yapay Zeka
Model: ChatGPT (GPT-5.1)

## Kullanılan Prompt
Html css ve javascript kullanarak basit web tabanlı balon patlatma oyunlarının örnek kod temellerini ver.


